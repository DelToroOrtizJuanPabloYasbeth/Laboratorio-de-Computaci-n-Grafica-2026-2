#include "Window.h"

Window::Window()
{
	width = 800;
	height = 600;
	for (size_t i = 0; i < 1024; i++)
	{
		keys[i] = 0;
	}
}

Window::Window(GLint windowWidth, GLint windowHeight)
{
	width = windowWidth;
	height = windowHeight;
	muevex = 2.0f;

	// --- INICIALIZACI�N DE NUEVAS VARIABLES (GODDARD) ---
	rotax = 0.0f;
	rotay = 0.0f;
	rotaz = 0.0f;
	articulacion1 = 0.0f; // Pata Delantera Derecha
	articulacion2 = 0.0f; // Pata Delantera Izquierda
	articulacion3 = 0.0f; // Pata Trasera Derecha
	articulacion4 = 0.0f; // Pata Trasera Izquierda
	mandibula = 0.0f;

	for (size_t i = 0; i < 1024; i++)
	{
		keys[i] = 0;
	}
}

int Window::Initialise()
{
	if (!glfwInit())
	{
		printf("Fall� inicializar GLFW");
		glfwTerminate();
		return 1;
	}

	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);

	mainWindow = glfwCreateWindow(width, height, "Practica 5: Jerarquia Goddard", NULL, NULL);

	if (!mainWindow)
	{
		printf("Fallo en crearse la ventana con GLFW");
		glfwTerminate();
		return 1;
	}

	glfwGetFramebufferSize(mainWindow, &bufferWidth, &bufferHeight);
	glfwMakeContextCurrent(mainWindow);
	createCallbacks();

	glewExperimental = GL_TRUE;

	if (glewInit() != GLEW_OK)
	{
		printf("Fall� inicializaci�n de GLEW");
		glfwDestroyWindow(mainWindow);
		glfwTerminate();
		return 1;
	}

	glEnable(GL_DEPTH_TEST);
	glViewport(0, 0, bufferWidth, bufferHeight);
	glfwSetWindowUserPointer(mainWindow, this);

	return 0;
}

void Window::createCallbacks()
{
	glfwSetKeyCallback(mainWindow, ManejaTeclado);
	glfwSetCursorPosCallback(mainWindow, ManejaMouse);
}

GLfloat Window::getXChange()
{
	GLfloat theChange = xChange;
	xChange = 0.0f;
	return theChange;
}

GLfloat Window::getYChange()
{
	GLfloat theChange = yChange;
	yChange = 0.0f;
	return theChange;
}

void Window::ManejaTeclado(GLFWwindow* window, int key, int code, int action, int mode)
{
	Window* theWindow = static_cast<Window*>(glfwGetWindowUserPointer(window));

	if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
	{
		glfwSetWindowShouldClose(window, GL_TRUE);
	}

	// Mantenemos tus teclas originales para muevex
	if (key == GLFW_KEY_Y)
	{
		theWindow->muevex += 1.0;
	}
	if (key == GLFW_KEY_U)
	{
		theWindow->muevex -= 1.0;
	}

	// --- NUEVAS TECLAS PARA GODDARD (Solo si se presionan o mantienen) ---
	if (action == GLFW_PRESS || action == GLFW_REPEAT)
	{
		// Pata Delantera Derecha (I / O) - L�mite 45 grados
		if (key == GLFW_KEY_I && theWindow->articulacion1 < 45.0f) theWindow->articulacion1 += 2.0f;
		if (key == GLFW_KEY_O && theWindow->articulacion1 > -45.0f) theWindow->articulacion1 -= 2.0f;

		// Pata Delantera Izquierda (K / L) - L�mite 45 grados
		if (key == GLFW_KEY_K && theWindow->articulacion2 < 45.0f) theWindow->articulacion2 += 2.0f;
		if (key == GLFW_KEY_L && theWindow->articulacion2 > -45.0f) theWindow->articulacion2 -= 2.0f;

		// Pata Trasera Derecha (N / M) - L�mite 45 grados
		if (key == GLFW_KEY_N && theWindow->articulacion3 < 45.0f) theWindow->articulacion3 += 2.0f;
		if (key == GLFW_KEY_M && theWindow->articulacion3 > -45.0f) theWindow->articulacion3 -= 2.0f;

		// Pata Trasera Izquierda (V / B) - L�mite 45 grados
		if (key == GLFW_KEY_V && theWindow->articulacion4 < 45.0f) theWindow->articulacion4 += 2.0f;
		if (key == GLFW_KEY_B && theWindow->articulacion4 > -45.0f) theWindow->articulacion4 -= 2.0f;

		// Mand�bula (F / G) - L�mite 45 grados
		if (key == GLFW_KEY_F && theWindow->mandibula > -45.0f)	theWindow->mandibula -= 2.0f;
		if (key == GLFW_KEY_G && theWindow->mandibula < 45.0f) theWindow->mandibula += 2.0f;
		

		// Rotaciones generales de Goddard (Opcionales: Flechas)
		if (key == GLFW_KEY_LEFT) theWindow->rotay -= 2.0f;
		if (key == GLFW_KEY_RIGHT) theWindow->rotay += 2.0f;
	}

	if (key >= 0 && key < 1024)
	{
		if (action == GLFW_PRESS)
		{
			theWindow->keys[key] = true;
		}
		else if (action == GLFW_RELEASE)
		{
			theWindow->keys[key] = false;
		}
	}
}

void Window::ManejaMouse(GLFWwindow* window, double xPos, double yPos)
{
	Window* theWindow = static_cast<Window*>(glfwGetWindowUserPointer(window));

	if (theWindow->mouseFirstMoved)
	{
		theWindow->lastX = xPos;
		theWindow->lastY = yPos;
		theWindow->mouseFirstMoved = false;
	}

	theWindow->xChange = xPos - theWindow->lastX;
	theWindow->yChange = theWindow->lastY - yPos;

	theWindow->lastX = xPos;
	theWindow->lastY = yPos;
}

Window::~Window()
{
	glfwDestroyWindow(mainWindow);
	glfwTerminate();
}