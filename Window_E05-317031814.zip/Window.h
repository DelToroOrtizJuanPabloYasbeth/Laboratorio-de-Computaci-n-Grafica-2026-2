#pragma once
#include<stdio.h>
#include<glew.h>
#include<glfw3.h>

class Window
{
public:
	Window();
	Window(GLint windowWidth, GLint windowHeight);
	int Initialise();
	GLfloat getBufferWidth() { return (GLfloat)bufferWidth; }
	GLfloat getBufferHeight() { return (GLfloat)bufferHeight; }
	GLfloat getXChange();
	GLfloat getYChange();
	GLfloat getmuevex() { return muevex; }
	bool getShouldClose() {
		return  glfwWindowShouldClose(mainWindow);
	}
	bool* getsKeys() { return keys; }
	void swapBuffers() { return glfwSwapBuffers(mainWindow); }

	// --- NUEVOS GETTERS PARA ARTICULACIONES Y ROTACIÓN ---
	GLfloat getrotax() { return rotax; }
	GLfloat getrotay() { return rotay; }
	GLfloat getrotaz() { return rotaz; }
	GLfloat getarticulacion1() { return articulacion1; } // Pata Delantera Derecha
	GLfloat getarticulacion2() { return articulacion2; } // Pata Delantera Izquierda
	GLfloat getarticulacion3() { return articulacion3; } // Pata Trasera Derecha
	GLfloat getarticulacion4() { return articulacion4; } // Pata Trasera Izquierda
	GLfloat getmandibula() { return mandibula; }		 // Mandibula

	~Window();

private:
	GLFWwindow* mainWindow;
	GLint width, height;
	bool keys[1024];
	GLint bufferWidth, bufferHeight;
	void createCallbacks();
	GLfloat lastX;
	GLfloat lastY;
	GLfloat xChange;
	GLfloat yChange;
	GLfloat muevex;
	bool mouseFirstMoved;

	// --- NUEVAS VARIABLES DE CONTROL ---
	GLfloat rotax, rotay, rotaz;
	GLfloat articulacion1, articulacion2, articulacion3, articulacion4;
	GLfloat mandibula;

	static void ManejaTeclado(GLFWwindow* window, int key, int code, int action, int mode);
	static void ManejaMouse(GLFWwindow* window, double xPos, double yPos);
};