#include "Window.h"

Window::Window()
{
	width = 800;
	height = 600;

	// Inicializaci�n de variables de control
	muevex = 0.0f;
	rotallanta = 0.0f;
	cofre = 0.0f;
	rotacion1 = 0.0f;
	rotacion2 = 0.0f;
	rotacion3 = 0.0f;

	// Estado inicial
	luzPrendida = true;
	colorCiclo = 0; // Inicia en el primer color

	for (size_t i = 0; i < 1024; i++)
	{
		keys[i] = 0;
	}
}

Window::Window(GLint windowWidth, GLint windowHeight)
{
	width = windowWidth;
	height = windowHeight;

	// --- INICIALIZACI�N DE VARIABLES ESPEC�FICAS (Coche y Octaedro) ---
	muevex = 0.0f;
	rotallanta = 0.0f;
	cofre = 0.0f;
	rotacion1 = 0.0f;
	rotacion2 = 0.0f;
	rotacion3 = 0.0f;

	// Estado inicial 
	//luzPrendida = true;
	luzPrendida = 0; // Iniciamos en el estado 0
	colorCiclo = 0;

	mouseFirstMoved = true;

	for (size_t i = 0; i < 1024; i++)
	{
		keys[i] = 0;
	}
}

int Window::Initialise()
{
	if (!glfwInit())
	{
		printf("Fall� inicializar GLFW");
		glfwTerminate();
		return 1;
	}
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);

	mainWindow = glfwCreateWindow(width, height, "Practica 7: Iluminacion 1", NULL, NULL);

	if (!mainWindow)
	{
		printf("Fallo en crearse la ventana con GLFW");
		glfwTerminate();
		return 1;
	}
	glfwGetFramebufferSize(mainWindow, &bufferWidth, &bufferHeight);
	glfwMakeContextCurrent(mainWindow);
	createCallbacks();

	glewExperimental = GL_TRUE;
	if (glewInit() != GLEW_OK)
	{
		printf("Fall� inicializaci�n de GLEW");
		glfwDestroyWindow(mainWindow);
		glfwTerminate();
		return 1;
	}

	glEnable(GL_DEPTH_TEST);
	glViewport(0, 0, bufferWidth, bufferHeight);
	glfwSetWindowUserPointer(mainWindow, this);

	return 0;
}

void Window::createCallbacks()
{
	glfwSetKeyCallback(mainWindow, ManejaTeclado);
	glfwSetCursorPosCallback(mainWindow, ManejaMouse);
}

GLfloat Window::getXChange()
{
	GLfloat theChange = xChange;
	xChange = 0.0f;
	return theChange;
}

GLfloat Window::getYChange()
{
	GLfloat theChange = yChange;
	yChange = 0.0f;
	return theChange;
}

void Window::ManejaTeclado(GLFWwindow* window, int key, int code, int action, int mode)
{
	Window* theWindow = static_cast<Window*>(glfwGetWindowUserPointer(window));

	if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
	{
		glfwSetWindowShouldClose(window, GL_TRUE);
	}

	if (action == GLFW_PRESS || action == GLFW_REPEAT)
	{
		// TRASLACI�N EN X (Teclas K / L)
		if (key == GLFW_KEY_K) {
			theWindow->muevex += 0.5f;
			theWindow->direccionHeli = 2; // Retroceder (X positiva)
		}
		if (key == GLFW_KEY_L) {
			theWindow->muevex -= 0.5f;
			theWindow->direccionHeli = 1; // Avanzar (X negativa)
		}

		// ROTACI�N LLANTAS EN Z (Teclas H / J)
		if (key == GLFW_KEY_H) theWindow->rotallanta += 5.0f;
		if (key == GLFW_KEY_J) theWindow->rotallanta -= 5.0f;

		// --- MOVIMIENTO PEZ (TECLAS F y G) --- 
		// Cambiamos el l�mite y el incremento para que sea suave y diagonal 
		if (key == GLFW_KEY_F && theWindow->cofre < 0.8f)   theWindow->cofre += 0.1f;
		if (key == GLFW_KEY_G && theWindow->cofre > -1.0f)  theWindow->cofre -= 0.1f;

		// --- ROTACIONES OCTAEDRO (B, N, M)  ---
		if (key == GLFW_KEY_B) theWindow->rotacion1 += 2.0f;
		if (key == GLFW_KEY_N) theWindow->rotacion2 += 2.0f;
		if (key == GLFW_KEY_M) theWindow->rotacion3 += 2.0f;

		// --- CICLO DE LUCES (Tecla E) ---
		if (key == GLFW_KEY_E && action == GLFW_PRESS)
		{
			theWindow->luzPrendida++; // Suma 1 al contador

			// Si el contador llega a 4, lo regresamos a 0
			if (theWindow->luzPrendida > 3)
			{
				theWindow->luzPrendida = 0;
			}
		}

		// --- CICLO DE COLORES FARO AUTO (Tecla Q) ---
		if (key == GLFW_KEY_Q && action == GLFW_PRESS)
		{
			theWindow->colorCiclo++;
			if (theWindow->colorCiclo > 5) // Reinicia tras pasar por los 6 colores
			{
				theWindow->colorCiclo = 0;
			}
		}
	}

	if (key >= 0 && key < 1024)
	{
		if (action == GLFW_PRESS)
		{
			theWindow->keys[key] = true;
		}
		else if (action == GLFW_RELEASE)
		{
			theWindow->keys[key] = false;
		}
	}
}

void Window::ManejaMouse(GLFWwindow* window, double xPos, double yPos)
{
	Window* theWindow = static_cast<Window*>(glfwGetWindowUserPointer(window));

	if (theWindow->mouseFirstMoved)
	{
		theWindow->lastX = xPos;
		theWindow->lastY = yPos;
		theWindow->mouseFirstMoved = false;
	}

	theWindow->xChange = xPos - theWindow->lastX;
	theWindow->yChange = theWindow->lastY - yPos;

	theWindow->lastX = xPos;
	theWindow->lastY = yPos;
}

Window::~Window()
{
	glfwDestroyWindow(mainWindow);
	glfwTerminate();
}